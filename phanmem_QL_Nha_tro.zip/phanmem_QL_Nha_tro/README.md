# phanmem_QL_Nha_tro

Sử dụng ide "microsoft visual studio" 
        quản lý db "sql server management"
        kết nối với db và sử dụng cách kết nối SQL

Cách cài đặt:
1. tải ide,sql server, SMSM SQL (query sql vào)
2. tạo tk mk admin bên SMSM SQL
3. đăng nhập dùng thử
