﻿namespace QL_Nha_Tro_Demo
{
    partial class DichVuPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dvcode = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dvname = new System.Windows.Forms.TextBox();
            this.dvprice = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dvdvt = new System.Windows.Forms.TextBox();
            this.adddv = new System.Windows.Forms.Button();
            this.fixdv = new System.Windows.Forms.Button();
            this.deldv = new System.Windows.Forms.Button();
            this.cleardv = new System.Windows.Forms.Button();
            this.addconfirmdv = new System.Windows.Forms.Button();
            this.fixconfirmdv = new System.Windows.Forms.Button();
            this.canceldv = new System.Windows.Forms.Button();
            this.exitdv = new System.Windows.Forms.Button();
            this.dataGridViewdv = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewdv)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Text", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(307, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 48);
            this.label1.TabIndex = 2;
            this.label1.Text = "Quản Lý Dịch Vụ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sitka Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(159, 24);
            this.label7.TabIndex = 7;
            this.label7.Text = "Thông tin dịch vụ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(114, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Mã Dịch Vụ: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(114, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "Giá Dịch Vụ: ";
            // 
            // dvcode
            // 
            this.dvcode.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dvcode.Location = new System.Drawing.Point(210, 109);
            this.dvcode.Name = "dvcode";
            this.dvcode.Size = new System.Drawing.Size(211, 24);
            this.dvcode.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(460, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tên Dịch Vụ: ";
            // 
            // dvname
            // 
            this.dvname.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dvname.Location = new System.Drawing.Point(561, 109);
            this.dvname.Name = "dvname";
            this.dvname.Size = new System.Drawing.Size(211, 24);
            this.dvname.TabIndex = 9;
            // 
            // dvprice
            // 
            this.dvprice.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dvprice.Location = new System.Drawing.Point(210, 157);
            this.dvprice.Name = "dvprice";
            this.dvprice.Size = new System.Drawing.Size(211, 24);
            this.dvprice.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(460, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "Đơn Vị Tính: ";
            // 
            // dvdvt
            // 
            this.dvdvt.Font = new System.Drawing.Font("Sitka Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dvdvt.Location = new System.Drawing.Point(561, 157);
            this.dvdvt.Name = "dvdvt";
            this.dvdvt.Size = new System.Drawing.Size(211, 24);
            this.dvdvt.TabIndex = 9;
            // 
            // adddv
            // 
            this.adddv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adddv.Location = new System.Drawing.Point(86, 198);
            this.adddv.Name = "adddv";
            this.adddv.Size = new System.Drawing.Size(82, 52);
            this.adddv.TabIndex = 10;
            this.adddv.Text = "Thêm";
            this.adddv.UseVisualStyleBackColor = true;
            this.adddv.Click += new System.EventHandler(this.adddv_Click);
            // 
            // fixdv
            // 
            this.fixdv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fixdv.Location = new System.Drawing.Point(174, 198);
            this.fixdv.Name = "fixdv";
            this.fixdv.Size = new System.Drawing.Size(82, 52);
            this.fixdv.TabIndex = 10;
            this.fixdv.Text = "Sửa";
            this.fixdv.UseVisualStyleBackColor = true;
            this.fixdv.Click += new System.EventHandler(this.fixdv_Click);
            // 
            // deldv
            // 
            this.deldv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deldv.Location = new System.Drawing.Point(262, 198);
            this.deldv.Name = "deldv";
            this.deldv.Size = new System.Drawing.Size(82, 52);
            this.deldv.TabIndex = 10;
            this.deldv.Text = "Xóa";
            this.deldv.UseVisualStyleBackColor = true;
            this.deldv.Click += new System.EventHandler(this.deldv_Click);
            // 
            // cleardv
            // 
            this.cleardv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cleardv.Location = new System.Drawing.Point(350, 198);
            this.cleardv.Name = "cleardv";
            this.cleardv.Size = new System.Drawing.Size(82, 52);
            this.cleardv.TabIndex = 10;
            this.cleardv.Text = "Xóa Trắng";
            this.cleardv.UseVisualStyleBackColor = true;
            this.cleardv.Click += new System.EventHandler(this.cleardv_Click);
            // 
            // addconfirmdv
            // 
            this.addconfirmdv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addconfirmdv.Location = new System.Drawing.Point(438, 198);
            this.addconfirmdv.Name = "addconfirmdv";
            this.addconfirmdv.Size = new System.Drawing.Size(82, 52);
            this.addconfirmdv.TabIndex = 10;
            this.addconfirmdv.Text = "Ghi";
            this.addconfirmdv.UseVisualStyleBackColor = true;
            this.addconfirmdv.Click += new System.EventHandler(this.addconfirmdv_Click);
            // 
            // fixconfirmdv
            // 
            this.fixconfirmdv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fixconfirmdv.Location = new System.Drawing.Point(526, 198);
            this.fixconfirmdv.Name = "fixconfirmdv";
            this.fixconfirmdv.Size = new System.Drawing.Size(82, 52);
            this.fixconfirmdv.TabIndex = 10;
            this.fixconfirmdv.Text = "Xác Nhận";
            this.fixconfirmdv.UseVisualStyleBackColor = true;
            this.fixconfirmdv.Click += new System.EventHandler(this.fixconfirmdv_Click);
            // 
            // canceldv
            // 
            this.canceldv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.canceldv.Location = new System.Drawing.Point(614, 198);
            this.canceldv.Name = "canceldv";
            this.canceldv.Size = new System.Drawing.Size(82, 52);
            this.canceldv.TabIndex = 10;
            this.canceldv.Text = "Hủy Bỏ";
            this.canceldv.UseVisualStyleBackColor = true;
            this.canceldv.Click += new System.EventHandler(this.canceldv_Click);
            // 
            // exitdv
            // 
            this.exitdv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exitdv.Location = new System.Drawing.Point(702, 198);
            this.exitdv.Name = "exitdv";
            this.exitdv.Size = new System.Drawing.Size(82, 52);
            this.exitdv.TabIndex = 10;
            this.exitdv.Text = "Thoát";
            this.exitdv.UseVisualStyleBackColor = true;
            this.exitdv.Click += new System.EventHandler(this.exitdv_Click);
            // 
            // dataGridViewdv
            // 
            this.dataGridViewdv.AllowUserToAddRows = false;
            this.dataGridViewdv.AllowUserToDeleteRows = false;
            this.dataGridViewdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewdv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridViewdv.Location = new System.Drawing.Point(12, 267);
            this.dataGridViewdv.Name = "dataGridViewdv";
            this.dataGridViewdv.ReadOnly = true;
            this.dataGridViewdv.RowHeadersWidth = 51;
            this.dataGridViewdv.RowTemplate.Height = 24;
            this.dataGridViewdv.Size = new System.Drawing.Size(836, 261);
            this.dataGridViewdv.TabIndex = 11;
            this.dataGridViewdv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewdv_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "maDV";
            this.Column1.HeaderText = "Mã Dịch Vụ";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "tenDV";
            this.Column2.HeaderText = "Tên Dịch Vụ";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "giaDV";
            this.Column3.HeaderText = "Giá Dịch Vụ";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 125;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "DVT";
            this.Column4.HeaderText = "Đơn Vị Tính";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 125;
            // 
            // DichVuPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 540);
            this.Controls.Add(this.dataGridViewdv);
            this.Controls.Add(this.exitdv);
            this.Controls.Add(this.canceldv);
            this.Controls.Add(this.fixconfirmdv);
            this.Controls.Add(this.addconfirmdv);
            this.Controls.Add(this.cleardv);
            this.Controls.Add(this.deldv);
            this.Controls.Add(this.fixdv);
            this.Controls.Add(this.adddv);
            this.Controls.Add(this.dvdvt);
            this.Controls.Add(this.dvname);
            this.Controls.Add(this.dvprice);
            this.Controls.Add(this.dvcode);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DichVuPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DichVuPage";
            this.Load += new System.EventHandler(this.DichVuPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewdv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox dvcode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox dvname;
        private System.Windows.Forms.TextBox dvprice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox dvdvt;
        private System.Windows.Forms.Button adddv;
        private System.Windows.Forms.Button fixdv;
        private System.Windows.Forms.Button deldv;
        private System.Windows.Forms.Button cleardv;
        private System.Windows.Forms.Button addconfirmdv;
        private System.Windows.Forms.Button fixconfirmdv;
        private System.Windows.Forms.Button canceldv;
        private System.Windows.Forms.Button exitdv;
        private System.Windows.Forms.DataGridView dataGridViewdv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}